console.log("静态网站加载成功！");
alert("欢迎来到我的静态网站！");


